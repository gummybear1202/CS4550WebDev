
background image taken from/credit to: https://www.duitang.com/blog/?id=671575402

Your name: Ruisi Su

Your CCIS username: rosaline

The URL of the github repo: https://github.com/gummybear1202/CS4550WebDev

The domain name you registered: rosaline.im

How far you got in the Codecademy tutorials.
